interface UserType{
    list:UserTypes[]
}
interface UserTypes{
    value: number;
    check: boolean;
}