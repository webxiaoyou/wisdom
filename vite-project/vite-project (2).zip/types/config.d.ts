interface TableColumn {
    title: string;
    dataIndex: string;
  }