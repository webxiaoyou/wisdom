import * as login from './module/login';
import * as index from './module/index';
import * as system from './module/system';
import * as tenement from './module/tenement';
export default Object.assign({}, login, index,system,tenement);
