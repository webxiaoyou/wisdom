interface PProperty {
    /**
     * 物业项目地址
     */
    address?: string;
    /**
     * 项目经理姓名
     */
    managerName?: string;
    pageNum?: number;
    pageSize?: number;
    /**
     * 请求参数
     */
    params?: any[];
    /**
     * 物业项目ID
     */
    propertyId?: number;
    /**
     * 物业项目名称
     */
    propertyName?: string;
}

interface PBuilding {
    /**
 * 楼栋ID
 */
    buildingId?: number;
    /**
     * 楼栋编号
     */
    buildingNumber?: string;
    pageNum?: number;
    pageSize?: number;
    /**
     * 请求参数
     */
    params?: any[];
    /**
     * 物业项目ID
     */
    propertyId?: number;
    /**
     * 物业项目名称
     */
    propertyName?: string;
}


interface PFloor {
    /**
     * 楼栋ID
     */
    buildingId?: number | string;
    buildingNumber?: string;
    /**
     * 楼层ID
     */
    floorId?: number;
    /**
     * 楼层编号
     */
    floorNumber?: number;
    pageNum?: number;
    pageSize?: number;
    /**
     * 请求参数
     */
    params?: any[];
}


 interface PPropertyUnit {
    /**
     * 认证状态（0未认证 1已认证 2认证未通过）
     */
    authenticationStatus?: string | number;
    /**
     * 楼栋ID
     */
    buildingId?: number;
    /**
     * 楼栋编号
     */
    buildingNumber?: string;
    /**
     * 创建者
     */
    createBy?: string;
    /**
     * 创建时间
     */
    createTime?: string;
    /**
     * 删除标志（0代表存在 1代表删除）
     */
    delFlag?: string;
    /**
     * 楼层ID
     */
    floorId?: number;
    /**
     * 楼层编号
     */
    floorNumber?: number;
    /**
     * 图片地址
     */
    imageUrl?: string;
    /**
     * 业主ID
     */
    ownerId?: number;
    pageNum?: number;
    pageSize?: number;
    /**
     * 请求参数
     */
    params?: any[];
    /**
     * 物业项目ID
     */
    propertyId?: number;
    /**
     * 物业项目名称
     */
    propertyName?: string;
    /**
     * 备注
     */
    remark?: string;
    /**
     * 房屋ID
     */
    unitId?: number;
    /**
     * 房屋编号
     */
    unitNumber?: string;
    /**
     * 更新者
     */
    updateBy?: string;
    /**
     * 更新时间
     */
    updateTime?: string;
    /**
     * 用户姓名
     */
    userName?: string;
}